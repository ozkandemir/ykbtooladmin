package admin

import (
	"fmt"
	"log"
	"net/http"
	_ "net/http/pprof"
	"sync"

	"github.com/gorilla/mux"
)

func Register(adminPort *int, group *sync.WaitGroup) {
	go func() {

		adminRouter := mux.NewRouter().StrictSlash(true)
		adminRouter.Path("/admin/number/").HandlerFunc(NumberQueryDBHandler).Methods("GET")
		adminRouter.Path("/admin/number/{name}").HandlerFunc(NumberQueryDBHandler).Methods("GET")
		adminRouter.HandleFunc("/admin/number", NumberCreationDBHandler).Methods("POST")
		adminRouter.HandleFunc("/admin/number/{name}", NumberDeletionDBHandler).Methods("DELETE")

		adminRouter.Path("/admin/repository/number").HandlerFunc(RepositoryInquiryHandler).Methods("GET")
		adminRouter.Path("/admin/repository/number/{name}").HandlerFunc(RepositoryInquiryHandler).Methods("GET")
		adminRouter.Path("/admin/repository/number/{name}").HandlerFunc(RepositoryCreateHandler).Methods("POST")
		adminRouter.Path("/admin/repository/synch").Queries("type", "{type}", "name", "{name}").HandlerFunc(SynchRepositoryHandler).Methods("GET")

		adminRouter.Path("/admin/engine/number").HandlerFunc(EngineInquiryHandler).Methods("GET")
		adminRouter.Path("/admin/engine/initialize").HandlerFunc(EngineInitializeHandler).Methods("GET")

		log.Printf("Admin Server is listening at %d", *adminPort)
		errAdmin := http.ListenAndServe(fmt.Sprintf(":%d", *adminPort), adminRouter)
		if errAdmin != nil {
			log.Fatalf("Admin server is failed: %v", errAdmin)
		}

		group.Done()

	}()
}
