package admin

import (
	"NumberGenerator/engine"
	"NumberGenerator/repository"
	"NumberGenerator/types"
	"encoding/json"
	"errors"
	"log"
	"net/http"

	"github.com/gorilla/mux"
)

func RepositoryInquiryHandler(w http.ResponseWriter, r *http.Request) {
	name := mux.Vars(r)["name"]

	var jsonResponse []byte

	if name == "" {
		values, _ := repository.NumberValuesRepository().ReadValues()
		jsonResponse, _ = json.Marshal(values)
	} else {
		value, _ := repository.NumberValuesRepository().ReadValue(name)
		jsonResponse, _ = json.Marshal(value)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(jsonResponse)

}

func RepositoryCreateHandler(w http.ResponseWriter, r *http.Request) {
	name := mux.Vars(r)["name"]

	numDef, _ := repository.NumberDBRepository().ReadNumberDefinition(name)

	if numDef != (types.NumberDefinition{}) {
		repository.NumberValuesRepository().CreateNumber(numDef)
	} else {
		jsonResponse, _ := json.Marshal(errors.New("Can not find NumberDefition in DB" + name))
		w.Write(jsonResponse)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

}

func SynchRepositoryHandler(w http.ResponseWriter, r *http.Request) {
	synchType := r.FormValue("type")

	if synchType == "structure" {
		log.Printf("SynchingRepository structure only")
		err := repository.NumberValuesRepository().RebuildRepositoryStructure()

		if err != nil {
			log.Printf("Repository build error %v", err)
			w.WriteHeader(http.StatusInternalServerError)
		}
	} else if synchType == "fromScratch" {
		log.Printf("SynchingRepository using Engine values")

		name := r.FormValue("name")
		values := make(map[string]int)
		if name == "" {
			numberDefinitions := engine.GetEngine().GetNumberDefinitions()

			for numDef := range numberDefinitions {
				values[numDef] = numberDefinitions[numDef].StartWith
			}
		} else {
			numDef := engine.GetEngine().GetNumberDefinitions()[name]
			values := make(map[string]int)
			values[numDef.Name] = numDef.StartWith
		}

		err := repository.NumberValuesRepository().RebuildRepositoryWithValues(values)
		if err != nil {
			log.Printf("Repository build error %v", err)
			w.WriteHeader(http.StatusInternalServerError)
		}

	} else if synchType == "fromDB" {
		log.Printf("SynchingRepository from DB values")

		name := r.FormValue("name")
		values := make(map[string]int)
		if name == "" {
			numberDefinitions, _ := repository.NumberDBRepository().ReadNumberDefinitions()

			for _, numDef := range numberDefinitions {
				values[numDef.Name] = numDef.StartWith
			}
		} else {
			numDef, _ := repository.NumberDBRepository().ReadNumberDefinition(name)
			values := make(map[string]int)
			values[numDef.Name] = numDef.StartWith
		}

		err := repository.NumberValuesRepository().RebuildRepositoryWithValues(values)
		if err != nil {
			log.Printf("Repository build error %v", err)
			w.WriteHeader(http.StatusInternalServerError)
		}

	} else {
		log.Printf("Wrong parameter type: %s", synchType)
		w.WriteHeader(http.StatusInternalServerError)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

}
