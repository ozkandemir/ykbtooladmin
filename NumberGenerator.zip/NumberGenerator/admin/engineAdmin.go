package admin

import (
	"NumberGenerator/engine"
	"encoding/json"
	"net/http"
)

func EngineInquiryHandler(w http.ResponseWriter, r *http.Request) {

	response, _ := json.Marshal(map[string]interface{}{"Values": engine.GetEngine().GetNumberValues(), "Definitions": engine.GetEngine().GetNumberDefinitions()})

	w.Write(response)
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

}

func EngineInitializeHandler(w http.ResponseWriter, r *http.Request) {

	engine.GetEngine().InitializeDefinitions()
	engine.GetEngine().InitializeLocks()
	engine.GetEngine().InitializeNumberValues()

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

}
