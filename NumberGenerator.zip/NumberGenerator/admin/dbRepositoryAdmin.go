package admin

import (
	"NumberGenerator/repository"
	"NumberGenerator/types"
	"encoding/json"
	"log"
	"net/http"

	"github.com/gorilla/mux"
)

func NumberCreationDBHandler(w http.ResponseWriter, r *http.Request) {
	var numDef types.NumberDefinition

	json.NewDecoder(r.Body).Decode(&numDef)

	if number, _ := repository.NumberDBRepository().ReadNumberDefinition(numDef.Name); number.Name != "" {
		log.Printf("NumberDefinition Exists:%s", numDef.Name)
	} else {
		log.Printf("Generating NumberDefinition :%v", numDef)
		repository.NumberDBRepository().CreateNumberDefinition(numDef)
		log.Printf("NumberDefinition created in Database:%v", numDef)
	}

}

func NumberDeletionDBHandler(w http.ResponseWriter, r *http.Request) {
	name := mux.Vars(r)["name"]

	repository.NumberDBRepository().DeleteNumberDefinition(name)
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
}

func NumberQueryDBHandler(w http.ResponseWriter, r *http.Request) {

	name := mux.Vars(r)["name"]
	var response map[string]types.NumberDefinition

	if name != "" {
		response = make(map[string]types.NumberDefinition)
		numberDefinitions, _ := repository.NumberDBRepository().ReadNumberDefinitions()
		for _, numDef := range numberDefinitions {
			if numDef.Name == name {
				response[numDef.Name] = numDef
				break
			}
		}
	} else {
		response = make(map[string]types.NumberDefinition)
		numberDefinitions, _ := repository.NumberDBRepository().ReadNumberDefinitions()
		for _, numDef := range numberDefinitions {
			response[numDef.Name] = numDef
		}
	}

	jsonResponse, err := json.Marshal(response)

	if err != nil {
		log.Printf("failed to serve: %v", err)
		w.WriteHeader(http.StatusInternalServerError)

	} else {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write(jsonResponse)
	}
}
