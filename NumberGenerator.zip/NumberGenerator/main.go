package main

import (
	"NumberGenerator/admin"
	"NumberGenerator/config"
	"NumberGenerator/engine"
	"flag"
	"log"
	"sync"
)

var (
	port            = flag.Int("port", 8080, "Server Listen Port")
	adminPort       = flag.Int("adminPort", 8081, "Admin Listen Port")
	singleInstance  = flag.Bool("single", false, "Single Instance true|false")
	applicationName = flag.String("applicationName", "numberGenerator", "Appliction Name in CloudFoundry")
	profile         = flag.String("profile", "numberGenerator", "Appliction Profile in CloudFoundry")
)

func main() {
	flag.Parse()
	config.LoadConfiguration(*applicationName, *profile)
	wg := new(sync.WaitGroup)

	wg.Add(2)
	log.Print("Ozkan")
	engine.Register(port, *singleInstance, wg)
	admin.Register(adminPort, wg)

	wg.Wait()
	log.Printf("Main process terminated")
}
