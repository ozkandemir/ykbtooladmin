package engine

import (
	pb "NumberGenerator/messages"
	"NumberGenerator/repository"
	"NumberGenerator/types"
	"errors"
	"fmt"
	"log"
	"net"
	"strconv"
	"sync"

	"golang.org/x/net/context"
	"google.golang.org/grpc"
)

type server struct {
	pb.UnimplementedNumberGeneratorServer
}

type numberEngine struct {
	numberDefinitions map[string]types.NumberDefinition
	numberLocks       map[string]*sync.Mutex
	numberValues      map[string]NumberValues
	singleInstance    bool
}

var numerator numberEngine

type NumberValues struct {
	Value     int
	cacheSize int
}

func (engine *numberEngine) InitializeDefinitions(names ...string) {
	if len(names) == 0 {
		numDefs, _ := repository.NumberDBRepository().ReadNumberDefinitions()
		for i := range numDefs {
			engine.numberDefinitions[numDefs[i].Name] = numDefs[i]
		}
	} else {

		if _, exists := engine.numberDefinitions[names[0]]; !exists {
			numDef, _ := repository.NumberDBRepository().ReadNumberDefinition(names[0])
			engine.numberDefinitions[numDef.Name] = numDef
		}
	}
}

func (engine *numberEngine) InitializeNumberValues(names ...string) error {
	if len(names) == 0 {
		numValues, err := repository.NumberValuesRepository().ReadValues()

		if err != nil {
			return err
		}

		for names, _ := range numValues {
			engine.numberValues[names] = NumberValues{Value: numValues[names], cacheSize: engine.numberDefinitions[names].CacheSize}
			repository.NumberValuesRepository().WriteValueWithLock(names, numValues[names]+engine.numberDefinitions[names].CacheSize)
		}

		return nil
	} else {
		numValue, _ := repository.NumberValuesRepository().ReadValue(names[0])
		engine.numberValues[names[0]] = NumberValues{Value: numValue, cacheSize: engine.numberDefinitions[names[0]].CacheSize}
		repository.NumberValuesRepository().WriteValueWithLock(names[0], numValue+engine.numberDefinitions[names[0]].CacheSize)

		return nil
	}
}

func (engine *numberEngine) InitializeLocks(names ...string) {
	if len(names) == 0 {
		for numDef := range engine.numberDefinitions {
			engine.numberLocks[numDef] = &sync.Mutex{}
		}
	} else {
		if engine.numberLocks[names[0]] == nil {
			engine.numberLocks[names[0]] = &sync.Mutex{}
		}
	}

}

func (engine *numberEngine) calculateNextValue(numberDefinition types.NumberDefinition, value int) (int, error) {

	var (
		err    error
		result int
	)

	if value+numberDefinition.Increment < numberDefinition.StartWith || value+numberDefinition.Increment > numberDefinition.MaxValue {
		if numberDefinition.Cycle {
			result = numberDefinition.StartWith
		} else {
			err = errors.New("number is Full")
		}
	} else {
		result = value + numberDefinition.Increment
	}

	return result, err

}

func (engine *numberEngine) getNextValue(name string) (int, error) {
	numberDefinition, ok := engine.numberDefinitions[name]
	var err error
	if !ok {
		err = errors.New(fmt.Sprintf("Undefined sequence name:%s", name))

	} else {
		engine.numberLocks[name].Lock()
		defer engine.numberLocks[name].Unlock()

		valueWithCache := engine.numberValues[name]
		value, err := engine.calculateNextValue(numberDefinition, valueWithCache.Value)
		valueWithCache.Value = value

		if err != nil {
			return 0, err
		}

		valueWithCache.cacheSize--
		if valueWithCache.cacheSize == 0 {
			if engine.singleInstance {
				err = engine.persistValueSingleInstance(name, value, numberDefinition.CacheSize)
			} else {
				err = engine.persistValue(name, value, numberDefinition.CacheSize)
			}
			if err != nil {
				return 0, err
			}

			valueWithCache.cacheSize = numberDefinition.CacheSize
		}
		engine.numberValues[name] = valueWithCache
		return value, err
	}

	return 0, err
}

func (engine *numberEngine) persistValueSingleInstance(name string, value int, cacheSize int) error {
	err := repository.NumberValuesRepository().WriteValue(name, value+cacheSize)
	if err != nil {
		return errors.New("Can not write value:" + name + " value:" + strconv.Itoa(value))
	}
	return nil
}

func (engine *numberEngine) persistValue(name string, value int, cacheSize int) error {
	mutex, err := repository.NumberValuesRepository().CreateMutex(name)
	if err != nil {
		return errors.New("Can not create Mutex:" + name)
	}
	acquire, err := mutex.Acquire()
	if err != nil {
		return errors.New("Can not acquire mutex:" + name)
	}
	if acquire {
		defer mutex.Release()
		value, _ = repository.NumberValuesRepository().ReadValue(name)
		err = repository.NumberValuesRepository().WriteValue(name, value+cacheSize)
		if err != nil {
			return errors.New("Can not write value:" + name + " value:" + strconv.Itoa(value))
		}
	}

	return nil
}

func (s *server) Generate(ctx context.Context, in *pb.GenerateRequest) (*pb.GenerateResponse, error) {
	response, err := numerator.getNextValue(in.Name)

	return &pb.GenerateResponse{Value: int32(response)}, err
}

func Register(serverPort *int, singleInstance bool, group *sync.WaitGroup) {
	numerator = numberEngine{
		numberDefinitions: make(map[string]types.NumberDefinition),
		numberLocks:       make(map[string]*sync.Mutex),
		numberValues:      make(map[string]NumberValues),
		singleInstance:    singleInstance,
	}
	numerator.InitializeDefinitions()
	numerator.InitializeLocks()
	err := numerator.InitializeNumberValues()
	if err != nil {
		log.Print("Can not read initial Values of Numbers from zookeeper")
	}

	go func() {
		lis, err := net.Listen("tcp", fmt.Sprintf("localhost:%d", *serverPort))

		if err != nil {
			log.Fatalf("failed to listen: %v", err)
		}

		s := grpc.NewServer()
		pb.RegisterNumberGeneratorServer(s, &server{})

		log.Printf("GRPC server listening at %v", lis.Addr())
		if err := s.Serve(lis); err != nil {
			log.Fatalf("failed to serve: %v", err)
		}

		group.Done()

	}()

}

func (engine *numberEngine) GetNumberDefinitions() map[string]types.NumberDefinition {
	return engine.numberDefinitions
}

func (engine *numberEngine) GetNumberValues() map[string]NumberValues {
	return engine.numberValues
}

func GetEngine() *numberEngine {
	return &numerator
}
