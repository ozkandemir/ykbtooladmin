package types

type NumberDirection int

type NumberDefinition struct {
	Name      string //Sequence_Name,Sequence_Code,Sequence_Key
	StartWith int    //start_sequence_no
	MaxValue  int    //end_sequence_no
	Increment int    //Sequence_Increment +
	Cycle     bool   //
	CacheSize int
}
