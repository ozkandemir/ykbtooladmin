package repository

import (
	"NumberGenerator/types"
	"database/sql"
	"log"
	"sync"

	"github.com/go-sql-driver/mysql"
)

type numberDBRepository struct {
	db *sql.DB
}

var singletonRepository *numberDBRepository
var once sync.Once

func openConnection() *sql.DB {
	// Capture connection properties.
	cfg := mysql.Config{
		User:      "Ozkan",
		Passwd:    "Ozkan",
		Net:       "tcp",
		Addr:      "127.0.0.1:3306",
		DBName:    "NumberDB",
		ParseTime: true,
	}

	db, err := sql.Open("mysql", cfg.FormatDSN())

	if err != nil {
		log.Fatal("Database Connection Failed")
	}

	log.Print("Database Connection Initialized")

	return db
}

func NumberDBRepository() *numberDBRepository {
	once.Do(
		func() {
			singletonRepository = &numberDBRepository{
				db: openConnection(),
			}

		})
	return singletonRepository
}

const SELECT_ALL_NUMBER_DEFINITIONS string = "SELECT NAME, STARTWITH, `MAXVALUE`, `INCREMENT`, `CYCLE`, CACHESIZE FROM NUMBER_TABLE"
const SELECT_NUMBER_DEFINITION string = "SELECT NAME, STARTWITH, `MAXVALUE`, `INCREMENT`, `CYCLE`, CACHESIZE FROM NUMBER_TABLE WHERE NAME = ?"
const INSERT_NUMBER_DEFINITION string = "INSERT INTO NUMBER_TABLE(NAME, STARTWITH, `MAXVALUE`, `INCREMENT`, `CYCLE`, CACHESIZE) VALUES (?,?,?,?,?,?)"
const DELETE_NUMBER_DEFINITION string = "DELETE NUMBER_TABLE WHERE NAME = ?"

func (numberDBRepository *numberDBRepository) ReadNumberDefinitions() ([]types.NumberDefinition, error) {
	var response []types.NumberDefinition

	rows, err := numberDBRepository.db.Query(SELECT_ALL_NUMBER_DEFINITIONS)
	if err != nil {
		log.Print("Can not select numbers %v", err)
		return nil, err
	} else {
		defer rows.Close()

		for rows.Next() {
			var numberDefinition types.NumberDefinition
			err = rows.Scan(&numberDefinition.Name, &numberDefinition.StartWith, &numberDefinition.MaxValue, &numberDefinition.Increment, &numberDefinition.Cycle, &numberDefinition.CacheSize)
			//			v := binary.BigEndian.Uint32(maxValue)
			//			log.Print(v)
			//numberDefinition.Increment, _ = fmt.Scanf("%d", increment[:])
			//numberDefinition.CacheSize, _ = fmt.Scanf("%d", cacheSize[:])
			if err != nil {
				log.Print("Error mapping DB data to Memory:%v", err)
			} else {
				response = append(response, numberDefinition)
			}
		}

	}

	return response, nil
}

func (numberDBRepository *numberDBRepository) ReadNumberDefinition(name string) (types.NumberDefinition, error) {
	var response types.NumberDefinition

	rows, err := numberDBRepository.db.Query(SELECT_NUMBER_DEFINITION, name)
	if err != nil {
		log.Print("Can not select numbers %v", err)
		return types.NumberDefinition{}, err
	} else {
		defer rows.Close()

		if rows.Next() {
			var numberDefinition types.NumberDefinition
			err = rows.Scan(&numberDefinition.Name, &numberDefinition.StartWith, &numberDefinition.MaxValue, &numberDefinition.Increment, &numberDefinition.Cycle, &numberDefinition.CacheSize)
			if err != nil {
				log.Print("Error mapping DB data to Memory")
			} else {
				response = numberDefinition
			}
		}

	}

	return response, nil
}

func (numberDBRepository *numberDBRepository) CreateNumberDefinition(numDef types.NumberDefinition) error {
	if exists, _ := numberDBRepository.ReadNumberDefinition(numDef.Name); exists == (types.NumberDefinition{}) {
		result, err := numberDBRepository.db.Exec(INSERT_NUMBER_DEFINITION, numDef.Name, numDef.StartWith, numDef.MaxValue, numDef.Increment, numDef.Cycle, numDef.CacheSize)
		if err != nil {
			return err
		}

		_, err = result.LastInsertId()
		if err != nil {
			return err
		}
	}
	return nil
}

func (numberDBRepository *numberDBRepository) DeleteNumberDefinition(name string) error {
	result, err := numberDBRepository.db.Exec(DELETE_NUMBER_DEFINITION, name)
	if err != nil {
		return err
	}

	_, err = result.RowsAffected()
	if err != nil {
		return err
	}
	return nil
}
