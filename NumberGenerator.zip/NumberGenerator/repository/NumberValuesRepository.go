package repository

import (
	"NumberGenerator/repository/recipes"
	"NumberGenerator/types"
	"errors"
	"fmt"
	"strconv"
	"sync"
	"time"

	"github.com/curator-go/curator"
)

const (
	ZookeeperMainPath             = "NumberGenerator"
	ZookeeperNumberValuesPaths    = "VALUES"
	ZookeeperNumberValuesFullPath = "/" + ZookeeperMainPath + "/" + ZookeeperNumberValuesPaths + "/"
	ZookeeperConnectionString     = "127.0.0.1:2181"

	ZookeeperNumberLocksPaths    = "LOCKS"
	ZookeeperNumberLocksFullPath = "/" + ZookeeperMainPath + "/" + ZookeeperNumberLocksPaths + "/"
)

var (
	curatorClient      curator.CuratorFramework
	curatorClientMutex = sync.Mutex{}
)

type NumberValuesRepositoryStruct struct{}

var sinletonValuesRepository *NumberValuesRepositoryStruct

func NumberValuesRepository() *NumberValuesRepositoryStruct {
	once.Do(func() {
		sinletonValuesRepository = &NumberValuesRepositoryStruct{}
	})
	return sinletonValuesRepository
}

func (repository *NumberValuesRepositoryStruct) ReadValues() (map[string]int, error) {
	//read all values stored in memory implementation
	//in this project it is zookeeper
	var result map[string]int
	result = make(map[string]int)

	client, curatorError := getCuratorClient()
	if curatorError != nil {
		return nil, errors.New(fmt.Sprintf("Zookeeper connection Error:%s", ZookeeperConnectionString))
	}

	numberPaths, err := client.GetChildren().ForPath("/" + ZookeeperMainPath + "/" + ZookeeperNumberValuesPaths)
	if err != nil {
		return nil, err
	}

	for _, path := range numberPaths {
		value, _ := client.GetData().ForPath(ZookeeperNumberValuesFullPath + path)
		result[path], _ = converter2int(value)
	}

	return result, err
}

func converter2int(data []byte) (int, error) {
	strValue := string(data[:])
	tempValue64, err := strconv.ParseInt(strValue, 10, 32)
	if err != nil {
		return 0, err
	}

	return int(tempValue64), nil

}

func (repository *NumberValuesRepositoryStruct) CreateMutex(numberAlias string) (*recipes.InterProcessMutex, error) {
	client, curatorError := getCuratorClient()
	if curatorError != nil {
		return nil, errors.New(fmt.Sprintf("Zookeeper connection Error:%s", ZookeeperConnectionString))
	}

	interProcessMutex, err := recipes.NewInterProcessMutex(client, ZookeeperNumberLocksFullPath+numberAlias)
	if err != nil {
		return nil, err
	}

	return interProcessMutex, nil
}

func (repository *NumberValuesRepositoryStruct) ReadValue(numberAlias string) (int, error) {

	client, curatorError := getCuratorClient()
	if curatorError != nil {
		return 0, errors.New(fmt.Sprintf("Zookeeper connection Error:%s", ZookeeperConnectionString))
	}

	path := ZookeeperNumberValuesFullPath + numberAlias
	data, err := client.GetData().ForPath(path)
	if err != nil {
		return 0, err
	}

	if number, err := converter2int(data); err != nil {
		return 0, err
	} else {
		return number, nil
	}

	return 0, nil
}

func (repository *NumberValuesRepositoryStruct) WriteValue(numberAlias string, value int) error {
	client, curatorError := getCuratorClient()
	if curatorError != nil {
		return errors.New(fmt.Sprintf("Zookeeper connection Error:%s", ZookeeperConnectionString))
	}

	path := ZookeeperNumberValuesFullPath + numberAlias
	_, err := client.SetData().ForPathWithData(path, []byte(strconv.Itoa(value)))
	if err != nil {
		return err
	}
	return nil
}

func (repository *NumberValuesRepositoryStruct) WriteValueWithLock(numberAlias string, value int) error {
	client, curatorError := getCuratorClient()
	if curatorError != nil {
		return errors.New(fmt.Sprintf("Zookeeper connection Error:%s", ZookeeperConnectionString))
	}

	interProcessMutex, err := recipes.NewInterProcessMutex(client, ZookeeperNumberLocksFullPath+numberAlias)
	if err != nil {
		return err
	}

	acquire, err := interProcessMutex.Acquire()
	if err != nil {
		return err
	}

	if acquire {
		defer interProcessMutex.Release()
		return repository.WriteValue(numberAlias, value)
	}

	return nil
}

func getCuratorClient() (curator.CuratorFramework, error) {
	var err error

	if curatorClient == nil {
		curatorClientMutex.Lock()
		if curatorClient == nil {
			retryPolicy := curator.NewExponentialBackoffRetry(time.Second, 3, 15*time.Second)
			curatorClient = curator.NewClient(ZookeeperConnectionString, retryPolicy)
			err = curatorClient.Start()
		}
		defer curatorClientMutex.Unlock()
	}

	return curatorClient, err
}

func (repository *NumberValuesRepositoryStruct) RebuildRepositoryWithValues(numberValues map[string]int) error {
	repository.RebuildRepositoryStructure()

	client, curatorError := getCuratorClient()
	if curatorError != nil {
		return errors.New(fmt.Sprintf("Zookeeper connection Error:%s", ZookeeperConnectionString))
	}

	for numDef := range numberValues {
		result, err := client.CheckExists().ForPath("/" + ZookeeperMainPath + "/" + ZookeeperNumberValuesPaths + "/" + numDef)
		if result == nil || err != nil {
			client.Create().ForPath("/" + ZookeeperMainPath + "/" + ZookeeperNumberValuesPaths + "/" + numDef)
		}

		path := ZookeeperNumberValuesFullPath + numDef
		client.SetData().ForPathWithData(path, []byte(strconv.Itoa(numberValues[numDef])))
	}

	for numDef := range numberValues {
		result, err := client.CheckExists().ForPath("/" + ZookeeperMainPath + "/" + ZookeeperNumberLocksPaths + "/" + numDef)
		if result == nil || err != nil {
			client.Create().ForPath("/" + ZookeeperMainPath + "/" + ZookeeperNumberLocksPaths + "/" + numDef)
		}

	}

	return nil
}

func (repository *NumberValuesRepositoryStruct) RebuildRepositoryStructure() error {
	client, curatorError := getCuratorClient()
	if curatorError != nil {
		return errors.New(fmt.Sprintf("Zookeeper connection Error:%s", ZookeeperConnectionString))
	}

	result, err := client.CheckExists().ForPath("/" + ZookeeperMainPath)
	if result == nil || err != nil {
		client.Create().ForPath("/" + ZookeeperMainPath)
	}

	result, err = client.CheckExists().ForPath("/" + ZookeeperMainPath + "/" + ZookeeperNumberValuesPaths)
	if result == nil || err != nil {
		client.Create().ForPath("/" + ZookeeperMainPath + "/" + ZookeeperNumberValuesPaths)
	}

	result, err = client.CheckExists().ForPath("/" + ZookeeperMainPath + "/" + ZookeeperNumberLocksPaths)
	if result == nil || err != nil {
		client.Create().ForPath("/" + ZookeeperMainPath + "/" + ZookeeperNumberLocksPaths)
	}

	return nil
}

func (repository *NumberValuesRepositoryStruct) CreateNumber(numberDefinition types.NumberDefinition) error {
	client, curatorError := getCuratorClient()
	if curatorError != nil {
		return errors.New(fmt.Sprintf("Zookeeper connection Error:%s", ZookeeperConnectionString))
	}

	result, err := client.CheckExists().ForPath("/" + ZookeeperMainPath + "/" + ZookeeperNumberValuesPaths + "/" + numberDefinition.Name)
	if result == nil || err != nil {
		client.Create().ForPath("/" + ZookeeperMainPath + "/" + ZookeeperNumberValuesPaths + "/" + numberDefinition.Name)
	}

	path := ZookeeperNumberValuesFullPath + numberDefinition.Name
	client.SetData().ForPathWithData(path, []byte(strconv.Itoa(numberDefinition.StartWith)))

	result, err = client.CheckExists().ForPath("/" + ZookeeperMainPath + "/" + ZookeeperNumberLocksPaths + "/" + numberDefinition.Name)
	if result == nil || err != nil {
		client.Create().ForPath("/" + ZookeeperMainPath + "/" + ZookeeperNumberLocksPaths + "/" + numberDefinition.Name)
	}

	return nil
}
