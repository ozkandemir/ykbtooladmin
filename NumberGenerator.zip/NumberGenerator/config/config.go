package config

import (
	"fmt"
	"log"
	"net/http"
	"os"

	"github.com/Piszmog/cloudconfigclient/v2"
)

var properties cloudconfigclient.PropertySource

func LoadConfiguration(applicationName string, profile string) {

	var configuration cloudconfigclient.Source

	if os.Getenv("VCAP_SERVICE") == "" {
		log.Println("VCAP_SERVICES is not present, trying standalone config server...")
		configServerUrl := os.Getenv("CONFIG_SERVER_URL")
		if configServerUrl == "" {
			configServerUrl = "http://localhost:9080"
		}

		client, err := cloudconfigclient.New(cloudconfigclient.Local(&http.Client{}, "http://localhost:9080"))
		if err != nil {
			log.Fatalln(err)
		}

		configuration, err = client.GetConfiguration(applicationName, profile)
		if err != nil {
			log.Fatalln(err)
		}

	} else {

		client, err := cloudconfigclient.New(cloudconfigclient.DefaultCFService())
		if err != nil {
			log.Fatalln(err)
		}

		// load a config file
		configuration, err = client.GetConfiguration(applicationName, profile)
		if err != nil {
			log.Fatalln(err)
		}

	}

	localProp, err := configuration.GetPropertySource("numberGenerator.yml")
	if err != nil {
		log.Fatalln("failed to find local property file")
	}

	properties = localProp

}

func GetProperty(key string) string {
	return fmt.Sprintf("%v", properties.Source[key])
}
